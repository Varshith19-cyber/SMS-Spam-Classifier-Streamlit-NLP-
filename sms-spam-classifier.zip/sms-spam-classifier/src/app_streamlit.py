import streamlit as st
import joblib
import os

MODEL_PATH = 'models/sms_spam_pipeline.joblib'

st.title('SMS Spam Classifier')
st.write('Type a message and get a prediction (Spam or Ham).')

if not os.path.exists(MODEL_PATH):
    st.warning('Model not found. Run `python src/train.py` to train and create the model.')
else:
    pipeline = joblib.load(MODEL_PATH)
    text = st.text_area('Message', value='Free entry in 2 a wkly comp to win FA Cup')
    if st.button('Classify'):
        pred = pipeline.predict([text])[0]
        prob = pipeline.predict_proba([text])[0].max() if hasattr(pipeline, 'predict_proba') else None
        label = 'SPAM' if pred==1 else 'HAM'
        st.write('Prediction:', label)
        if prob is not None:
            st.write('Confidence:', round(prob,3))
