import os
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
import requests
import io

os.makedirs('models', exist_ok=True)
os.makedirs('data', exist_ok=True)

DATA_CSV = 'data/spam.csv'

def download_dataset():
    # SMS Spam Collection dataset mirror (UCI classic). If network blocked, user can place spam.csv manually.
    url = 'https://raw.githubusercontent.com/justmarkham/pycon-2016-tutorial/master/data/sms.tsv'
    print('Downloading dataset from', url)
    r = requests.get(url)
    r.raise_for_status()
    df = pd.read_csv(io.StringIO(r.text), sep='\t', header=None, names=['label','message'])
    df.to_csv(DATA_CSV, index=False)
    print('Saved', DATA_CSV)

def load_data():
    if not os.path.exists(DATA_CSV):
        download_dataset()
    df = pd.read_csv(DATA_CSV)
    # normalize label to 0/1
    df['label_num'] = df['label'].map({'ham':0, 'spam':1})
    return df

def main():
    df = load_data()
    X = df['message']
    y = df['label_num']
    X_train,X_test,y_train,y_test = train_test_split(X,y, test_size=0.2, random_state=42)
    pipeline = Pipeline([
        ('tfidf', TfidfVectorizer(stop_words='english', max_features=5000)),
        ('clf', LogisticRegression(max_iter=1000))
    ])
    pipeline.fit(X_train, y_train)
    preds = pipeline.predict(X_test)
    print(classification_report(y_test, preds))
    joblib.dump(pipeline, 'models/sms_spam_pipeline.joblib')
    print('Saved model to models/sms_spam_pipeline.joblib')

if __name__ == '__main__':
    main()
