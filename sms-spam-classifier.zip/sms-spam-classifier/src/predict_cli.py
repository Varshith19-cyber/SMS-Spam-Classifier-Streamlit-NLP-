import joblib
import argparse
import os
MODEL_PATH = 'models/sms_spam_pipeline.joblib'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--text', required=True)
    args = parser.parse_args()
    if not os.path.exists(MODEL_PATH):
        raise SystemExit('Model not found. Run: python src/train.py')
    pipe = joblib.load(MODEL_PATH)
    pred = pipe.predict([args.text])[0]
    print('SPAM' if pred==1 else 'HAM')

if __name__ == '__main__':
    main()
