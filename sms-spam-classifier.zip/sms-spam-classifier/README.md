# SMS Spam Classifier + Streamlit App

Train a simple SMS spam classifier and run a Streamlit demo to classify new messages.

## Contents
- `data/` — place `spam.csv` (SMS Spam Collection) here or use the train script to download it (instructions inside).
- `src/train.py` — trains a TF-IDF + LogisticRegression pipeline and saves `models/sms_spam_pipeline.joblib`.
- `src/app_streamlit.py` — Streamlit app to try messages live.
- `requirements.txt`

## Quick start
```bash
cd sms-spam-classifier
pip install -r requirements.txt
python src/train.py           # trains and saves model (it will try to download dataset if missing)
streamlit run src/app_streamlit.py
```
